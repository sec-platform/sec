# IDE / Workbench 需求与供给组合压力样本

> **角色：非权威组合研究。** 本页完整保留曾用于工作台范本的具体 Rule、Subject、UI、执行、发行和供给职责划分，用于研究通用 Requirement、组合、实现选择、Target 与 Evidence 机制能否在没有内置 IDE 产品类型时闭合。它不是 Gift Core 的标准 Rule catalog、内置 IDE SDK、默认 Profile、官方产品模板或当前实现路线；其中具体名字、数量、平台、默认资产和方法编号都不能取得 Core authority。现行通用合同见[需求定义与供给合同][k1]。

本章只在该研究载荷内部固定工作台范本使用的局部合同：公开主体、字段和值、约束含义以及实现消除责任。它不是一份宣称已安装的 `gift/spec/*` 包目录。**每个名字在本章有明确设计，当前没有发布其运行库或实现适配。**文档结构检查只能检查这份源是否引用了已写出的合同，不能证明这些合同已经被实现。

普通项目使用这些合同不复制本章。生产实现应把同样的精确公开定义和方法置于原Definition/ImportedModuleView与语言锁中；当前文档表不能在每次构建中被AI重新解释成新语义。纯底层库也能实现一个要求，不必伪造同名Gift算法体。

## 定义不是营销名称，参数也不是任意JSON

一个RequirementDefinition必须拥有以下内容：精确身份/版本；字段schema与值域/单位/引用种类；被约束的SubjectSchema；适用输入与观察；正常、错误、帧及进展条件；组合/默认/失效规则；真实实现方法或明确未实现；方法前提与证据责任。未知字段、同一字段重复、普通字符串代替名义枚举、无绑定引用均不能默默通过。

`SubjectRef<K>`标识被约束对象，不是机器地址；`RuleRef`引用需求定义；`DesignRef<S>`引用一参数复合需求定义；`PredicateRef<X>`引用有确定语义的谓词/关系；`Selector<S>`标识有明确成员解释和范围的主体集合。它们是已有语义实体的类型化引用，不能互相强转。此处不新增运行时句柄协议。

记录字段排列只是书写顺序。`operations/features/access/platforms/modes/targets`为有限集合，重复值去重不产生重复调用，并保留来源；`scopes`的实际优先级由`precedence`字段规定，不由列表顺序猜。指向同一准确逻辑主体的硬约束合取；同名义类型但身份不同的Subject分别受约束，除非存在明确关系连接二者。类型相同不等于主体相同。同一主体同一字段的相冲突要求不按最后一项覆盖。必要的关系顺序、输入多重性和事件顺序由其具体合同拥有。

除了下文明确的变体，表中给出的名义值具有其完整说明，不能用名字相近的另一个值替换。定义可以继续发布新变体而不新增语言关键词，旧绑定不自动升级。结构条款中的`require`标签（可选文本示意同名）不是构建时调用构造器，方法被选择与执行属于编译/受授权运行阶段。

## Workbench主体图是观察模型，不是强制服务图

`gift/spec/ide.Workbench`是本文范本的名义根schema。角色从一个根s派生稳定局部身份；两个不同根的相同角色不是同一主体。角色在模型上存在不意味着对应运行实体一定被分配；只有有效要求需要它时才取得实现。

| 路径 | Subject种类与公开观察 |
|---|---|
| s.workspace | Workspace：根、资源身份、枚举覆盖、读写与工作区状态 |
| s.documents | DocumentSpace：文档集合、实例、版本、字节/文本及草稿 |
| s.editor | EditorSurface：视图、选区、输入、焦点及编辑动作 |
| s.history | EditHistory：动作组、撤销/重做及相交资源 |
| s.search | SearchSurface：请求、查询代、结果、覆盖和选择 |
| s.replace | ReplacementSurface：预览计划、接受、应用与逐项结果 |
| s.languages | LanguageServiceSet：版本化方法能力、文档输入及结果 |
| s.diagnostics | DiagnosticSet：生产者、范围、输入代与诊断 |
| s.tasks | TaskSet：声明入口、实际运行及子资源寿命 |
| s.terminal | TerminalSet：进程输入、输出、信号与关闭 |
| s.debug | DebugSessionSet：已加载来源、停点、控制及观察 |
| s.tests | TestSet：发现范围、案例、期望、实际运行与结果 |
| s.vcs | VersionIntegration：工作树、暂存、提交与远端状态 |
| s.extensions | ExtensionSet：内容、贡献、能力需求与隔离运行 |
| s.settings | ClientConfiguration：Workbench客户端scope内的schema、局部值、秘密引用和生效版本 |
| s.shell | WorkbenchSurface：布局、命令、焦点、主题、消息与可访问性 |
| s.release | DeliverySet：各平台源树、成员、依赖、来源及发行条件 |
| s.effects | EffectBoundary：根下所有受管外部作用的真实准入和结算 |

每项字段的`on/documents/workspace/...`必须匹配对应种类，s本身为Workbench。`experience.Commands.targets`接收异质的公开动作主体引用，但不是任意JSON；每个主体必须有真实的动作/输入/输出/错误描述。Role到实现可是一对多或多个角色共享一个实体，前提是身份、生命周期和隔离要求允许；不得按同样字符串给每个需求各分配一个不同模型。

## 本范本采用的具体需求定义

下列所有契约都要求其定义的正常功能在满足公开前提且资源允许的合法输入上可用，不能用总是返回Unavailable空实现满足。环境前提只能来自公开定义及已接受部署，不可由方法为了通过而私自加强。失败结果保持草稿/来源/恢复责任，不能作为吞掉硬要求的捷径。

### workspace.Roots

打开、关闭、列举根与资源。重叠根的同一资源只在明确展示语义允许时重复展示；搜索去重不能跨主体误合并。空工作区仍可用。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.workspace` | 根集合的主体身份 |
| `multiplicity` | `workspace.Many` | 允许零个或多个根；未打开根不算失败 |
| `identity` | `workspace.ProviderIdentity` | 按提供者的规范资源身份，显示路径不定义相等 |
| `nested` | `workspace.ExplicitMembership` | 嵌套根的归属选择显式，不按扫描先后隐式抢占 |

**实现责任：**[工作区/提供者][k2]。**失败与限制：**提供者不能枚举时返回覆盖缺口；不把不可读根当空根。

### workspace.Files

文件树提供读取、新建、移动、删除；移动更新资源关系但不凭显示名改写身份。相交编辑草稿不因操作失败被静默删除。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.workspace` | 同一工作区主体 |
| `operations` | `[workspace.Read, workspace.Create, workspace.Move, workspace.Delete]` | 要求的真实资源操作集合 |
| `conflicts` | `workspace.PreserveDrafts` | 相交未保存内容必须保留或明确冲突 |
| `access` | `workspace.RuntimeGrant` | 产品在每次作用处检查实际许可，不是此声明给予许可 |

**实现责任：**[工作区/提供者][k2]。**失败与限制：**跨卷、大小写等价、只读和并发修改分别走提供者合同，不承诺跨文件原子。

### workspace.Snapshot

每次读取绑定根、模型实例与内容代；已打开文档按当前模型解释，其他资源按提供者版本。显式报告枚举缺口、失效或取消。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.workspace` | 捕获的工作区主体 |
| `documents` | `s.documents` | 此工作区采用的开放文档集合 |
| `precedence` | `workspace.OpenModelWins` | 已打开模型对该资源权威于旧磁盘内容 |
| `absence` | `workspace.OpenEmptySuppressesDisk` | 打开模型零命中或空内容也抑制旧磁盘结果 |

**实现责任：**[文档与快照][k2]。**失败与限制：**无法得到同代稳定输入时保留部分结果/失效；不拼出伪全局同时刻。

### workspace.Recovery

异常退出后能区分已保存、草稿及未知现场；恢复草稿前核原身份与前像，冲突保留。已开始的外部操作按原意图查回而不是再执行。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `documents` | `s.documents` | 可恢复草稿主体 |
| `history` | `s.history` | 与草稿绑定的编辑历史 |
| `mode` | `workspace.RecoverDraftNotReplayEffects` | 恢复内容与历史不重放外部执行 |

**实现责任：**[保存/历史/恢复][k2]。**失败与限制：**缺恢复存储能力时不能承诺持久草稿；恢复失败不覆盖新现场。

### editing.Documents

每个文档有模型实例、版本、语言与原编码依据；合法范围不拆代理对，跨协议坐标需转换。二进制/未知编码不假装可无损文本编辑。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.documents` | 文档集合主体 |
| `resourceIdentity` | `editing.FromWorkspace` | 与根/文件操作共用资源身份 |
| `coordinates` | `editing.UnambiguousSourcePositions` | 位置绑定准确文本及可核对的坐标含义；字节、标量、字素及UTF-16等内部/外部单位由适配转换，不强制一种内部缓冲 |
| `encoding` | `editing.PreserveOrExplicitConvert` | 保存保留可复现原编码，改变必须是明确转换 |
| `newlines` | `editing.PreserveOriginal` | 保留原换行；显式规范化是独立行为 |

**实现责任：**[文档与快照][k2]。**失败与限制：**无法无损解码时保留字节并要求明确文本/二进制选择，不静默替换字符。

### editing.Editor

支持打开、切换、选区、输入、删除、分屏、查找本文件；同一文档在多个视图中的文本一致，光标/滚动可按视图独立。输入组合/撤销按真实编辑动作分组。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.editor` | 编辑交互主体 |
| `documents` | `s.documents` | 实际被编辑的模型集合 |
| `selections` | `editing.Multiple` | 多个选区与光标及确定合并/冲突规则 |
| `views` | `editing.ManyViewsOneModel` | 多个视图绑定同一模型而不是各复制一份内容 |

**实现责任：**[编辑/界面总成][k2]。**失败与限制：**IME和坐标映射能力不足不得标成完整编辑支持；重叠编辑按固定规则处理。

### editing.History

撤销和重做保留精确作用资源、模型和次序。跨资源撤销组不等于磁盘事务；用户之后继续修改时必须协调，不能覆盖现场。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.history` | 历史主体 |
| `documents` | `s.documents` | 同一模型集合 |
| `grouping` | `editing.ByUserAction` | 一组实际用户动作形成一个逻辑撤销组 |
| `undo` | `editing.IfCurrentCompatible` | 只有现场/历史允许才执行逆编辑 |

**实现责任：**[保存/历史/恢复][k2]。**失败与限制：**不兼容前像或已失效外部观察返回冲突；不把补偿称为时间倒流。

### editing.Save

保存选定模型，记录参与者前后像和各提供者结果；未保存、保存失败和未知不可报成全完成。这里只要求普通可见保存，不冒称断电耐久或跨文件事务。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `documents` | `s.documents` | 编辑完成的模型 |
| `workspace` | `s.workspace` | 真正持久化目的地 |
| `completion` | `editing.PerResource` | 模型编辑与各资源保存分别结算 |
| `participants` | `editing.ExplicitChanges` | 格式化等保存参与者产生的字节变化可见 |
| `conflicts` | `editing.PreserveBoth` | 外部写冲突保留双方内容/依据 |

**实现责任：**[保存/历史/恢复][k2]。**失败与限制：**提供者没有耐久、CAS或冲突能力时不代签；改了但未保存只重试合格保存。

### search.Text

搜索多根文件并按当前模型覆盖磁盘；范围、大小写、包含/排除和语言/编码选择进入请求。结果支持导航与逐文件聚合。完整上下文与截短展示分开。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.search` | 查询、结果与覆盖主体 |
| `workspace` | `s.workspace` | 检索范围 |
| `documents` | `s.documents` | 同一编辑内容集合 |
| `pattern` | `search.LiteralAndDeclaredRegexDialect` | 字面量及绑定的正则方言；不是所有引擎等价 |
| `results` | `search.MatchWithSourceVersion` | 完整命中含模型/源版本与坐标 |
| `coverage` | `search.Explicit` | 完整、截断、未读、失败、取消不同 |
| `cancellation` | `search.SupersededCannotPublish` | 旧查询可在途但不能发布为当前 |

**实现责任：**[搜索][k2]。**失败与限制：**正则不可保持或覆盖不足时给真实缺项；不因命中数达到展示上限声称全部。

### search.Replace

从真实命中与完整文本计算编辑及前后像；预览只改独立模型。应用前及最后写边界核实际模型版本，逐资源编辑/保存。并发更新使旧计划失效。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.replace` | 替换计划主体 |
| `matches` | `s.search` | 来源为同一搜索结果 |
| `documents` | `s.documents` | 写入同一组模型 |
| `preview` | `search.DisplayedEditsOnly` | 预览固定选择、替换表达式、源和精确编辑 |
| `acceptance` | `search.DisplayedPlan` | 应用接受的是显示计划而非当前输入框重算值 |
| `stale` | `search.Reject` | 源/模型/策略过期时本计划拒绝应用 |
| `scope` | `search.SelectedOrCompleteScope` | 允许明确选择；未明确选择的全量要求必须完整 |
| `recovery` | `search.ReconcileNoBlindReplay` | 分项查回，不重放已发生编辑 |

**实现责任：**[安全替换][k2]。**失败与限制：**不存在最终版本保护能力时拒绝强写入；不把只读命中默默剔除后称全部替换。

### search.Presentation

结果树、计数、选中范围、差异预览及逐资源结算使用同一事实来源；焦点/展开状态保留；移除显示项不是删除资源。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `search` | `s.search` | 结果模型 |
| `replace` | `s.replace` | 替换计划 |
| `shell` | `s.shell` | 交互展示主体 |
| `navigation` | `search.ExactSourceMatch` | 定位到准确结果来源，陈旧项显示失效 |
| `readonly` | `search.InspectableNotWritable` | 只读项可看可导航但不可写 |

**实现责任：**[编辑/界面总成][k2]。**失败与限制：**不能显示源或完整差异时不得当作用户已确认；展示预算不决定计算覆盖。

### language.Providers

语言识别、token、诊断及导航使用明确服务和精确输入；本例发行至少绑定TypeScript服务及纯文本回退。新语言通过同一能力接口添加，不保证任意语言。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.languages` | 语言服务集合 |
| `documents` | `s.documents` | 输入的文档 |
| `settings` | `s.settings` | 语言工具的客户端设置投影；编译/目标/native配置仍由各自canonical owner提供 |
| `capability` | `language.NegotiateExact` | 逐方法、编码和版本协商 |
| `unsupported` | `language.ExplicitUnavailable` | 未支持与零结果区分 |

**实现责任：**[语言服务][k2]。**失败与限制：**服务退出或不支持分项报告；不得用旧磁盘分析结果覆盖新缓冲。

### language.Diagnostics

完整空结果只清本生产者及所声明完整范围；旧回调不得清新诊断。报告错误、未覆盖与工具失败，允许独立生产者共同贡献。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.diagnostics` | 诊断集合 |
| `producers` | `s.languages` | 生产者范围 |
| `documents` | `s.documents` | 输入源 |
| `publication` | `language.ByProducerScopeAndRevision` | 发布及清除绑定生产者、范围、版本和请求代 |

**实现责任：**[语言服务][k2]。**失败与限制：**没有版本依据或覆盖信息时降为有标识的历史/局部观察。

### language.Refactoring

更名、改签名、快速修复和导入整理输出普通候选；多文件与资源变化分清原坐标及順序语义，不能自动执行服务附带任意命令。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.languages` | 重构服务 |
| `documents` | `s.documents` | 目标模型 |
| `workspace` | `s.workspace` | 文件和资源变更范围 |
| `edits` | `language.VersionedGroup` | 整组编辑的前像与外部范围语义固定 |
| `preservation` | `language.EffectsAndEvaluationOrder` | 声称保持的改签名/更名需保留实参次序和效果 |

**实现责任：**[语言服务][k2]。**失败与限制：**未知动态引用和非事务宿主保留缺口；不把字段替换成功称为语义保持。

### language.Assistance

补全主编辑与导入形成同一候选；定义、引用、含义和参数提示按真实符号及输入返回。新建议不成为已安装库或已证明事实。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.languages` | 辅助服务 |
| `features` | `[language.Completion, language.Definition, language.References, language.Hover, language.Signature]` | 本例需要的辅助方法 |
| `truth` | `language.CandidateNotEstablishedFact` | 推测建议与真实已绑定位置分开 |

**实现责任：**[语言服务][k2]。**失败与限制：**过期建议重新求解或报告冲突，不按旧偏移直接写。

### execution.Tasks

运行、构建和watch以明确输入/工具/环境开始；只停止所拥有任务，结果绑定制品；C2不改写C1正在运行实例。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.tasks` | 构建/运行任务主体 |
| `workspace` | `s.workspace` | 任务输入 |
| `selection` | `execution.DeclaredEntries` | 发现或声明的准确入口 |
| `inputs` | `execution.ArgumentVector` | 参数向量，无隐式shell拼接 |
| `effect` | `execution.RuntimeGrant` | 实际启动许可 |
| `lifetime` | `execution.OwnedScope` | 启动、子任务、结果与退出有拥有者 |

**实现责任：**[任务/终端/测试][k2]。**失败与限制：**环境缺失或启动未知分别处理；一个等待者取消不停止他人共享任务。

### execution.Terminal

支持文本输入、关闭输入、信号和PTY尺寸；同请求查回，未知发送不全量重放；秘密输入与回显披露分别保护。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.terminal` | 交互终端主体 |
| `tasks` | `s.tasks` | 实际进程集合 |
| `input` | `execution.OrderedNoUnknownReplay` | 输入排队、短写和未知消费范围分别处理 |
| `streams` | `execution.SeparateWithGaps` | stdout/stderr各自顺序，截断显式 |
| `lifetime` | `execution.ExplicitCloseAndReconcile` | EOF、signal、进程及子树退出分别结算 |

**实现责任：**[任务/终端/测试][k2]。**失败与限制：**无PTY只提供真实管道能力；目标未退出不因窗口关闭就报结束。

### execution.Debug

启动/附加、断点、暂停、继续、单步、变量及退出共用准确目标身份；默认不把有作用求值伪装成只读查看。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.debug` | 调试会话 |
| `tasks` | `s.tasks` | 启动或附加目标 |
| `documents` | `s.documents` | 显示和来源对应 |
| `capability` | `execution.Negotiated` | 按真实驱动能力启用 |
| `source` | `execution.LoadedArtifact` | 来源跟随已加载制品，不是latest |
| `handles` | `execution.StopScoped` | 栈和值句柄只对当前停点有效 |
| `controls` | `execution.NoDuplicateUncertainCommand` | 同一接受的控制在响应未知时不能重复作用；实际驱动可用串行未决槽实现，不把槽本身当产品要求 |

**实现责任：**[调试][k2]。**失败与限制：**未支持断点或线程控制不可静默扩域；失联不盲重发单步。

### execution.Tests

按框架发现、筛选、运行、复跑与调试；覆盖和基准保存分母及环境。复跑通过不覆盖前次失败，改期望属于需求变化。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.tests` | 案例和结果主体 |
| `tasks` | `s.tasks` | 真实运行 |
| `workspace` | `s.workspace` | 案例与工程来源 |
| `discovery` | `execution.LazyCoverageExplicit` | 懒发现与完整范围不同，执行发现需许可 |
| `input` | `execution.ExactCandidate` | 测试必须消费声明的候选及完整相关输入 |
| `outcomes` | `execution.NoCasesNotPass` | 空、跳过、失败、中断、通过分开 |

**实现责任：**[任务/终端/测试][k2]。**失败与限制：**无覆盖输入能力不能拿磁盘旧版绿色代签当前缓冲。

### vcs.Integration

提供状态、差异、暂存、提交、分支和同步；保留非本次变更，检查准确提交输入。相同tree不代签提交号敏感结果。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.vcs` | 版本集成主体 |
| `workspace` | `s.workspace` | 工作区真实内容 |
| `view` | `vcs.WorktreeIndexCommitSeparate` | 工作树/暂存/提交分开 |
| `selection` | `vcs.Explicit` | 本次选定完整差异，不自动全暂存 |
| `merge` | `vcs.CandidateAndPreconditions` | 合并候选及预期头固定 |

**实现责任：**[版本集成][k2]。**失败与限制：**失败不自动reset/clean/强推；远端成功与本地跟进分开。

### extension.Execution

安装选定扩展、贡献命令/视图/语言功能，运行部分在真实隔离边界内；资源超限可停止扩展而保全用户草稿。第三方任意原生代码不能绕过声明直接获得同域权限。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.extensions` | 扩展集合 |
| `effects` | `s.effects` | 所有外部作用的边界 |
| `modes` | `[extension.DeclarativeContribution, extension.IsolatedExecutable]` | 允许声明贡献和隔离执行扩展 |
| `authority` | `extension.DeclaredAndGranted` | 声明需求与取得许可分别检查 |
| `failure` | `extension.ContainAndDisable` | 故障隔离并可禁用 |

**实现责任：**[扩展与作用隔离][k2]。**失败与限制：**仅同进程JS标签不构成强隔离；只有具备执行域/系统拦截能力的供给可满足本条。

### extension.Compatibility

升级检查贡献身份、接口和状态迁移；旧运行固定旧扩展解释，不自动热替换闭包。本例不承诺兼容全部VS Code扩展。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.extensions` | 相同扩展集合 |
| `api` | `extension.VersionedCapability` | 接口按语义能力版本匹配 |
| `installed` | `extension.ExactContent` | 安装内容与声明及来源绑定 |
| `unknown` | `extension.RejectUnsupportedRequirement` | 未知必需能力拒绝启用 |

**实现责任：**[扩展与作用隔离][k2]。**失败与限制：**签名只证明签发来源不证明安全或合同正确；缺必需迁移不启用新版本。

### settings.ClientConfiguration

本合同只拥有**Client authority**下的Workbench设置，不是全工程`UniversalConfig`。按schema解码客户端值、单位、descriptor default与scope传播并显示生效来源；恢复默认删除当前客户端scope的局部贡献，而不是写入通用null。语言工具、任务视图及UI可以消费这一客户端投影；Author Control、目标/native配置、External事实和Runtime输入继续由各自canonical owner持有，消费者需要时通过明确投影读取，不能复制进`s.settings`。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.settings` | 客户端设置主体；不拥有编译/目标/runtime配置 |
| `scopes` | `[settings.User, settings.Workspace, settings.WindowOrView]` | 客户端可继承scope沿`User → Workspace → Window/View`；不把产品默认伪装成scope |
| `defaultRule` | `settings.VersionedDescriptorDefault` | 省略时仅由该键descriptor的版本化default规则补值；default不是更低“来源层” |
| `merge` | `settings.DescriptorMergeRule` | 同键贡献按descriptor声明的局部合并/冲突规则解释；策略hard约束单独合取，不采用通用last-write-wins |
| `secret` | `settings.ReferenceOnly` | 秘密仅引用，值走秘密提供者 |
| `changes` | `settings.Versioned` | 变更固定输入与受影响实例 |

**实现责任：**[客户端设置][k2]。**失败与限制：**未知必需键或类型错误拒绝相交行为；不能让工程覆盖管理员硬约束。

### policy.Network

未经当前许可不得上传代码、遥测或下载内容；显式同步/安装可在其范围许可下运行。仅记录自报标志不满足禁止要求。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.effects` | 产品根内全部网络作用，含生成依赖和扩展 |
| `policy` | `policy.OriginAndPurposeGrant` | 按主体/来源/目的/时间授权 |
| `background` | `policy.DeniedUnlessGranted` | 后台联网默认拒绝，用户可明示授予目的 |

**实现责任：**[扩展与作用隔离][k2]。**失败与限制：**无法封闭的原生/外部进程作用必须明确扩大可信域或拒绝该强画像，不能宣称通杀所有外部系统。

### policy.Destruction

删文件、发送、发布、安装等作用逐项准入；当前无结果不能证明旧在途请求不会晚到。需要恢复时保留同一意图与真实后继。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.effects` | 破坏性/不可逆作用主体 |
| `policy` | `policy.ScopeAndRevisionGrant` | 许可绑定实际对象范围和有效前置 |
| `retry` | `policy.OnlyEffectiveIdempotencyOrFinality` | 仅有效同意图去重或旧尝试终结后确认无效果可重试 |

**实现责任：**[保存/历史/恢复][k2]。**失败与限制：**目标没有去重/查回/终结时保留未知并协调；不换ID盲重放。

### ide.Scope

把本产品边界明确化：一个本地可扩展IDE，不冒称完全重现Code-OSS所有功能；用户数据、编辑和本地任务在无云账号时可使用。范围排除不能删除下游本来依赖的必要前置。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s` | 整个产品根 |
| `account` | `ide.NotRequired` | 本地功能不以云账号为前置 |
| `collaboration` | `ide.NotIncluded` | 此发行不交付多人实时共同编辑 |
| `marketplace` | `ide.NotRequired` | 扩展可显式本地安装，不以商店服务为前置 |
| `cloudSync` | `ide.NotIncluded` | 此发行不宣称云配置同步 |

**实现责任：**[产物与平台][k2]。**失败与限制：**要求实时协作/商店/云同步时形成新独立需求，不静默套用现有离线合同。

### experience.Layout

声明可观察布局和可达入口，不指定DOM层数、类名或事件总线。窗口缩小时区域可折叠但所有核心动作仍可通过键盘/命令到达。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.shell` | 工作台交互表面 |
| `editor` | `s.editor` | 主编辑区 |
| `workspace` | `s.workspace` | 文件树 |
| `search` | `s.search` | 搜索表面 |
| `diagnostics` | `s.diagnostics` | 问题表面 |
| `terminal` | `s.terminal` | 底部交互终端 |
| `panes` | `experience.WorkbenchLayout` | 左侧文件/搜索，中央编辑，底部问题/终端，可隐藏、分屏和调整 |
| `visibility` | `experience.TaskContext` | 显示状态按任务上下文而非改变实际需求 |

**实现责任：**[编辑/界面总成][k2]。**失败与限制：**实际用户界面必须交付；只提供后端端口不能满足本条。未承诺像素级复制某现有IDE。

### experience.Commands

所有产品公开动作必须有至少一个可达入口；常用编辑/搜索/运行/调试具有键盘绑定和冲突解释。三入口复用同一动作而非三次执行。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.shell` | 命令入口表面 |
| `targets` | `[s.workspace, s.editor, s.search, s.replace, s.languages, s.tasks, s.terminal, s.debug, s.tests, s.vcs, s.extensions, s.settings]` | 公开可执行动作的语义主体集合 |
| `access` | `[experience.Menu, experience.Palette, experience.Keyboard]` | 菜单、命令面板及键盘的等义入口 |
| `registry` | `experience.TypedCommandSchema` | 从供给公开动作签名派生命令/参数/消息，不手抄三份处理器 |
| `enablement` | `experience.CurrentContext` | 是否可用以当前主体能力/选择/权限决定 |

**实现责任：**[编辑/界面总成][k2]。**失败与限制：**没有动作描述或消息资产的供给不能被称为已完成UI；隐藏按钮不能代替作用边界许可。

### experience.Accessibility

不依赖颜色、鼠标悬停或视觉图形才能完成核心操作；弹窗关闭恢复合法焦点，动态结果更新不抢输入焦点。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.shell` | 整个交互表面 |
| `focus` | `experience.DeterministicKeyboardRoute` | 固定焦点次序、模态约束和返回位置 |
| `labels` | `experience.AccessibleNames` | 核心控件具有角色/名称/状态 |
| `status` | `experience.TextAndAssistiveNotification` | 错误、运行和保存结果文字可见并对辅助技术可得 |

**实现责任：**[编辑/界面总成][k2]。**失败与限制：**需实际可访问性树与平台验证；有label字段不能代签所有辅助技术可用。

### experience.Appearance

主题和消息是可替换资产，不由函数名猜文本。默认样式和文案由随供给提供的固定资源承担，项目只写有品牌差异的覆盖。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.shell` | 界面表面 |
| `theme` | `experience.SemanticTokens` | 颜色字体空间用语义token，默认取绑定DesktopBaseline1主题 |
| `locale` | `experience.MessageCatalog` | 消息键及参数签名从所用能力目录生成/合并；此例默认zh-CN，en为回退 |
| `missingText` | `experience.VisibleFallback` | 缺文案有可见回退和构建诊断，不显示空按钮 |

**实现责任：**[编辑/界面总成][k2]。**失败与限制：**自定义精确品牌、图标或文案未提供时不假装已取得；此例明确采用供给默认。

### delivery.Source

产物有可构建的选定源树、输入清单和启动入口；不把生成源打出来等同于本机已经安装或打包成功。可以复用成熟组件源码/库，不复制算法作为作者输入。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.release` | 交付主体 |
| `language` | `delivery.TypeScript` | 要求TS源输出，不指定Gift实现语言 |
| `target` | `s` | 完整选定产品 |
| `host` | `delivery.DesktopHostContract` | 桌面宿主能力合同；具体实现由合格Binding决定 |
| `members` | `delivery.CompleteSelectedRoots` | 源/配置/资源/必要运行库和许可齐全 |
| `ownership` | `delivery.GeneratedFromIntent` | 派生工程不反过来成为必须双写的作者源 |

**实现责任：**[产物与平台][k2]。**失败与限制：**缺宿主、资源或目标方法时报告具体缺件；不能仅输出接口骨架。

### delivery.Compatibility

每平台分别验证宿主、构建、ABI、资源与行为；目标自由不能偷换产品合同。许可有真实来源与适用方式，不以“开源”泛化。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.release` | 发行组合 |
| `platforms` | `[delivery.Windows, delivery.Linux, delivery.MacOS]` | 要求的三个独立平台输出 |
| `unsupported` | `delivery.ExplicitNoArtifact` | 某平台不合格时该输出明确失败，不冒称三平台完成 |
| `dependencies` | `delivery.Locked` | 依赖与方法解释固定到实际内容 |
| `licensing` | `delivery.CompatibleDistribution` | 选定源码、库、资源和商标使用满足实际分发条件 |

**实现责任：**[产物与平台][k2]。**失败与限制：**不能确定分发条件则保留实际待决而非签法律保证；未实现平台继续保留源。

### delivery.Identity

同一封存解释可重建；自然语言只用于创作/精化，固定源之后不重新重解语义。实现优化可替换Binding但形成新制品并维护原来源。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s.release` | 产物集合 |
| `sources` | `delivery.ExactIntentAndBinding` | 意图、采用的定义、方法/参数和实际输入共同固定 |
| `mappings` | `delivery.RequirementToArtifact` | 从需求出现到生成模块/约束/说明的来源关系 |
| `rebuild` | `delivery.NoFreshNaturalLanguageInterpretation` | 固定构建不再次请求AI猜需求 |

**实现责任：**[产物与平台][k2]。**失败与限制：**外部工具非确定或环境未固定时如实报告，不凭哈希存在宣布位级可复现。

### quality.Admission

交互与工作队列不能为追求最终完成无限占用资源；预算作用于真实分配和依赖。清理必要责任优先于新增工作。此条不承诺某个延迟百分位。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s` | 全部受管运行/查询 |
| `policy` | `quality.LimitsFromRuntimeProfile` | 使用被绑定部署配置中的容量，不伪造未测性能数值 |
| `overload` | `quality.BoundedQueueOrReject` | 内存/并发/待办有实际界限，超限暂停或拒绝 |
| `loss` | `quality.Explicit` | 截断、丢弃、取消和未完成可观察 |

**实现责任：**[资源与偏好][k2]。**失败与限制：**没有可执行资源计量/拒绝边界时不宣称有界；硬实时需要独立时间语义。

### quality.Cost

只在硬条件已满足的供给中比较；未知测量不伪装成零成本。已有合格稳定绑定优先，只有显式优化/更换触发才重新评估。

| 字段 | 本源的值/引用 | 准确含义 |
|---|---|---|
| `on` | `s` | 选择的产品实例 |
| `metric` | `quality.ResidentMemory` | 驻留内存；第二条可以用InteractiveLatency |
| `priority` | `1` | 正整数偏好次序，数值小者先；同次序为Pareto而非凭空加权 |
| `workload` | `quality.DeclaredWorkload` | 比较按目标相同且明确的工作负载；未测为未知 |

**实现责任：**[资源与偏好][k2]。**失败与限制：**未测时可以按已委派稳定规则选可行者，但不能声称最优。完整比较依[分层偏序][k3]：高层未定不跳到低层，折中不假装相等，区间和统计口径按真实依据判断；偏好不得隐藏在供给可选择的any/exists体中。

## 样本选定的源变体

`search.Replace.stale`除`search.Reject`之外定义`search.RebuildThenConfirm`：旧计划一律不得写；系统可以取得新快照重算并展示新计划；必须取得对新计划的重新接受，旧接受不能迁移。它不是后台按新文本直接应用。两种值的差异是产品行为，不能由并发度或缓存优化偷偷切换。

`quality.Cost.metric`包含`quality.ResidentMemory`和`quality.InteractiveLatency`。前者是同负载下测量驻留内存，后者按同一事件起终点和采样口径测量交互延迟；未提供负载/测量时标未知。priority为正整数，按较小值先比较；同priority使用Pareto关系。只有高层全部已知相等才继续低层，折中、缺测、不可比较或重叠区间保留在该层，不能跳过；任何未知不得按零排序。比较和剪枝的具体规则由[实现选择][k3]拥有。当前锁合格而未请求优化时复用，不为了比较永远阻塞生成。无法分出优劣时，已委派的固定保守顺序可以选择可行者，但没有“最优”结论。

当前搜索请求的正则方言是显式输入/发行能力的一部分：发行必须公开至少一个已固定、定义清楚的RegexDialect，不能拿两个方言的同串模式互相冒充；字面量查找总可用。无方言参数的请求只能使用发行明确公布的默认；不根据当前机器安装了哪个搜索器改变解释。模式、大小写、全词、包含/排除及跨行设置的精确含义也在对应发行的PatternSpec中固定。这里允许采用不同方言发行，不承诺本例已经逐字复制某现有IDE的全部搜索行为；要求指定方言时它成为硬字段并限制供给。

默认界面资产`DesktopBaseline1`必须提供可读主题、消息键/参数签名、中文与英文回退、菜单/命令及键盘路由。在生产绑定中这些是确切文件/值，不是名字推断；本次只定义其行为与资产义务，没有生成冒充已完成的UI文件。作者后来提供品牌资产时按实际差异替换，来源与许可同时改变。

<a id="generic-requirement-constructors"></a>

## 新需求无需先增加官方业务名字

复合需求定义可以由已有要求组成，没有算法体也仍是一等定义。直接结构编码使用[有限逻辑组合][k4]；以下更广开放构造是领域层的合同，必须分别具有实际字段、类型、解释和方法，不能因表内有名字就默认具有任意结构读取或求解能力。

| 公开需求构造 | 字段与准确含义 | 非平凡边界 |
|---|---|---|
| logic.AllOf | on:Subject<S>；parts:有限List<DesignRef<S>>。同一on同时满足所有parts | 空集合只无附加条件，不生成正常功能；功能由其他要求承担 |
| logic.AnyOf | on:Subject<S>；alternatives:非空List<DesignRef<S>>。选择至少一个完整满足的方案 | 不是每个方案挑一部分；不默认在运行期重选；相交硬条件仍都成立 |
| logic.When | on:Subject<S>；condition:PredicateRef<S>；then:DesignRef<S>；else:DesignRef<S>可选 | condition必须标编译期或运行期；未能决定的静态条件不能当false；运行分支需对应方法 |
| logic.Each | over:Selector<S>；rule:DesignRef<S> | 静态集要求真实覆盖；动态集要求每个实际成员进入时约束生效，不能只检查构建时成员 |
| relation.Transform | on:Subject<Function<I,O>>；accept:PredicateRef<BeforeAfter<I,O>>；frame:PredicateRef<`BeforeAfter<World>`> | 明确正常输入、允许结果及保持项；一个事后校验器不自动是转换实现 |
| state.Machine | on:Subject<S>；model:已绑定状态/事件/守卫/转移模型 | 表达状态语义，不要求作者写switch；非法、同时触发、资源与历史由状态合同处理 |
| temporal.Invariant | on:Subject<S>；property:PredicateRef<Observation<S>> | 声明全局保持，选择证明/构造/运行阻止方法；事后发现不等于预防 |
| temporal.Progress | on:Subject<S>；trigger/goal:PredicateRef<Observation<S>>；under:明确环境/公平性合同 | 永不触发或永不返回不能冒充正常可用；环境假设不能循环自证 |
| privacy.Noninterference | on:Subject<S>；secret/public:Selector；relation:多运行观察合同 | 不等于一次运行不写日志；侧信道与时间是否纳入由观察合同决定 |
| quality.StatisticalTarget | on:Subject<S>；population/method/metric/bound:精确绑定 | 一次样例/固定随机种子不证明分布保证；生成可输出待验证义务，不造证据 |

构造引用的是原RequirementTerm和对应域方法，不是普通JSON任意扩展口。结构any允许空域并将其解释为false；本表logic.AnyOf则以非空alternatives作为其接口前提，两者的定义域不同，不互相放宽字段。结构when/forEach/exists只覆盖准确有限静态条件与列表；logic.When/Each中的运行条件或动态集合仍需相应时序、成员与实现合同，不能用一次构建快照冒充全部运行范围。没有实现/逻辑规则的新PredicateRef可作为研究材料保存；只有取得其确切含义与方法后才能在强生成或证明中使用。真正新领域引入必要观察、参数和解释，仍沿原SemanticDialect/Definition；不强制全部变成标量函数或万能谓词求解。

### 一个没有算法体的完整计算需求

“区间规范化”的输入是有限List<{start:Int,end:Int}>，采用半开区间。start>end为明确输入错误；start=end为空区间忽略。输出同覆盖、按start升序、区间非空、彼此不重叠也不相邻。这些条件唯一确定按并集最大连通分量划分的输出；数学Int不溢出。

```gift
import "gift/spec/interval" as interval;
export design Normalize(f: interval.Normalization) {
  require interval.Input { on: f, invalid: interval.RejectReversed, empty: interval.Ignore };
  require interval.Coverage { on: f, relation: interval.SameUnion };
  require interval.Canonical { on: f, order: interval.StartAscending, adjacency: interval.Merge };
}
```

这里interval三个合同的字段、类型和语义就由上述段落定义：on为同一个Normalization函数主体，invalid/empty/order/adjacency为本节名义枚举；Input引入合法域及错误，Coverage与Canonical约束成功结果。不调用排序、不写循环。排序扫描是一个实现：取得副本、按(start,end)排序、逐项归并当前最大end、输出最大不相接段；平衡树是另一实现。方法要证明同覆盖与最大段、处理原输入帧并绑定Int目标。此例只给设计，没有运行求解器或生成该程序。

作者可以把这三个要求封装成Normalize，下一处直接use它。再要求“输出与输入一一对应、区间数保持”时会与重叠输入合并发生冲突；不能为了支持新条件悄悄减少原输入域。改变为闭区间需要不同整数邻接语义，不能只替换展示括号。

<a id="realization-methods"></a>

## 从需求到真实目标的供给责任

这些是**拟定方法合同**，不是已存在包或已运行方法。已有成熟总成可一次履行多组，库签名和许可、模型/错误/资源能力须先核定；不能按产品关键词自动从网上挑包并执行。

| 方法 | 输入与必须消除的义务 | 目标结构与剩余资格 |
|---|---|---|
| 工作区/提供者 | 根身份、嵌套归属、枚举、选定读写操作及当前许可 | 根/资源适配、文件树动作；逐provider的读写/一致性/目录能力必须真实 |
| 文档与快照 | 开放模型优先、相同模型身份、版本/编码/坐标、稳定快照 | 文档模型、快照和坐标适配；文本缓冲可以复用成熟实现，不把复制当原子快照 |
| 保存/历史/恢复 | 动作分组、编辑与保存分项、冲突、在途操作终结/去重 | 历史服务、恢复存储、保存适配；强保证取决于最后修改/持久化边界 |
| 编辑/界面总成 | 多视图一模型、结果与预览展示、命令/焦点/主题/消息/无障碍 | 成熟编辑组件及声明式布局/命令生成；真实UI及资产必需，不生成空按钮 |
| 搜索 | 精确PatternSpec、工作区/模型覆盖、结果版本与覆盖、取消 | 按已选方言的搜索器、模型搜索、聚合器；不一致正则必须换方法/声明缺口 |
| 安全替换 | 冻结编辑、显示计划接受、过期政策、逐项应用/保存/恢复 | 私有Plan/Preview/Apply状态及适配；没有最终版本保障不得宣称强写 |
| 语言服务 | 固定输入、公开方法、诊断代和组合编辑语义 | 合格原生/LSP服务桥、诊断分区、候选编辑；未知引用及覆盖不被抹去 |
| 任务/终端/测试 | 入口、准确输入、寿命、交互输入未知、防重复、案例范围 | 执行器/PTY/测试桥与资源域；全部作用在授权边界，不靠UI按钮阻止越权 |
| 调试 | 实际驱动能力、已加载来源、停点句柄、单未决控制 | 调试桥/来源映射/会话状态；驱动不支持必需范围则缺项，不伪造观察 |
| 版本集成 | 工作树/暂存/提交分开、准确选择、合并前提 | 原生VCS适配和候选树；不通过reset/强推修复未知现场 |
| 扩展与作用隔离 | 内容/接口、动态成员、能力与许可、网络/秘密边界 | 真实执行域隔离和完整中介、贡献注册；同进程标签不满足强隔离 |
| 客户端设置 | schema、单位、Client scope、descriptor merge/default、秘密引用、传播范围 | Client设置解码和更改传播；只投影其他authority的事实，不复制其owner，任何局部值都不能覆盖硬政策 |
| 产物与平台 | 完整源/配置/资源/许可、精确绑定、平台根、来源 | 组合器/桌面入口/平台适配；各平台分别成功，未构建不称安装完成 |
| 资源与偏好 | 部署容量、准入/拒绝、工作负载和可比成本 | 真实计量/预算边界、有限方法选择；未测不造SLA，偏好不降硬条件 |

每个方法返回实现片段及精确读集、前提、消除义务、未解义务、新增效果和成员贡献，沿原MethodSpec/LoweringResult处理。供给中的字符串名称不是证明；规则有DesignSpecified、方法Implemented、符合性Verified和采用Adopted等不同证据层，状态由原位置拥有。

### 最先可实现的完整垂直路径

先让同一结构读取链取得复合定义、条款和完整主体关系；所选计算/文本前端只在相应区域启用；实现“工作区/提供者、文档与快照、编辑/界面总成、搜索、安全替换、保存/历史/恢复”这一条相交平台子集，驱动工作台中的编辑→搜索→冻结预览→写入→保存的实际结果；其他要求仍在源中明确未实现。**这是实现分期，不把其余要求删掉来称全产品完成。**随后按真实需求接入语言服务、任务/终端/测试、调试、版本集成、扩展隔离、客户端设置、产物/平台与资源/偏好等剩余职责并逐平台封闭，始终使用同一最终源而不是每期换一门作者语言。

现有Code-OSS可以作为成熟总成候选，其实际接口、隔离和合同差异需检查；也可以组合其他合格编辑器/搜索/宿主供给。两者都从需求向实现选择，不从目标仓库目录反推作者必须写同样多文件。当前没有确定或修改这些第三方仓库，也没有声称已完成任一整套总成的适配。

## 工作台动作的完整接合

本页规则目录维护字段和含义；规则成员数由该canonical目录本身派生，不成为架构常量。所选Shell与各功能的实际屏幕、动作、共享对象、正常/失败/退出及非GUI调用关系，由[Studio交互压力样本][k5]进一步限定；其中冻结编辑、版本化应用和一种目标布局的 lowering 压力见[IDE降低与目标布局压力样本][k6]。两者共同构成该WorkBench定义；不因JSON能展开就声称每项动作已实现，也不让UI隐藏必需动作取得资格。

[k1]: ../../docs/20-语义与组合/作者语义/需求规则与供给合同.md
[k2]: #realization-methods
[k3]: ../../docs/30-实现解析/实现选择/实现解析与候选资格.md#preference-partial-order
[k4]: ../../docs/10-作者与输入/作者源/结构化源码.md#finite-requirement-composition
[k5]: Studio交互产品.md
[k6]: IDE降低与目标布局.md

### 差异压力：同一IDE动作跨版本编辑与调试资格

先从语义目录选择一个实际源节点，冻结其身份和候选修订；用户在另一客户端重命名公开端口后，旧Inspector不能按列表位置提交编辑。诊断工具引用的原生编译结果只属于其原版Target/环境，不能替新Revision签发PASS；已生成结构和真实保存、发布状态分别回读。

**对应公共合同（本页不取得定义权）：** [离线客户端、分页视图与操作前像的同步](../../docs/80-开发者与接口/客户端/工作台布局与交互.md#gift-client-view-consistency)；[跨版本证据重用的有效性与被遮蔽失败](../../docs/60-保证与证据/保证/解释与证据接纳.md#gift-evidence-time-reuse)。本段是条件情景和可反驳的预期，不是已执行的产品测试。

### 额外组合压力：设计提案冻结后需求与候选全集同时变化

工作台产品设计者在 `Requirement@r5` 上批准搜索比较：方案 A 共享一个远端搜索 Provider，方案 B 使用两个隔离的本地搜索实例；候选 `DesignCandidate@c8` 在当时负查找“没有其他可用供给”的开放枚举中排序领先。另一作者随后把离线隐私限制改为 `Requirement@r6`，同时新的合格本地 Provider 注册。旧 `c8` 的内容哈希和曾通过的方案反例均未改变，但决定资格依赖的硬要求和负查询全集已经改变。

正确的可检查响应不把 `c8` 直接升级成现行 `Binding`，也不直接用编辑器文本版本冲突替代设计冲突：读取候选正/负基础、枚举水位、当前硬要求及策略，返回受影响责任的 `stale` 与候选重评，保留没有共同依赖的UI布局决定。重新评估后可在原授权内采用一个方案写回正式 Definition/Requirement/Contract owner；如果“远端与本地”存在无法消除的安全或价值差异，则保留明确未决。工作区代码变更、真正Provider准入、目标构建和部署分别按原协议继续，本段没有声称任何一个真实 IDE 已运行该测试。

**唯一规范入口：**[设计候选基础与并发采纳](../../docs/30-实现解析/实现选择/设计空间搜索与求解.md#基础资格和并发采纳)；[实现候选与绑定分工](../../docs/30-实现解析/实现选择/实现解析与候选资格.md#问题定义)；[冻结资格](../../docs/70-工程系统与演进/演进与实施/实施/主线前沿-工作组织与成熟度准入.md#设计冻结)。本段只提出可反驳的组合时序，不新增业务标准规则或写权。
