# License map

Gift uses two standard licenses, selected by the kind of material rather than by repository location alone.

## Software and executable engineering material

Repository-owned source code, tests, tools, workflow and build configuration, machine-consumed examples, schemas, fixtures, and other executable or implementation material are licensed under the [Mozilla Public License 2.0](../LICENSE). The SPDX identifier is `MPL-2.0`.

MPL-2.0 applies without the Exhibit B “Incompatible With Secondary Licenses” notice. Modifications to MPL-covered source files remain governed by MPL-2.0 when distributed, while separate files may be combined with them in a Larger Work under other terms as allowed by the license.

Using Gift to inspect, generate, compile, or modify a target workspace does not by itself apply MPL-2.0 to that workspace or its output. Material copied from Gift, including example code or implementation fragments, retains its applicable license.

## Documentation and specifications

Repository-owned Markdown, including root design entrypoints, `docs/**`, `research/**`, `fixtures/**`, `witnesses/**`, human-readable `_meta/*.md` material, diagrams embedded in those works, and other human-readable specifications are licensed under [Creative Commons Attribution 4.0 International](CC-BY-4.0.txt). The SPDX identifier is `CC-BY-4.0`. Generated reader/audit views, when materialized outside the package, inherit the license of the source text they project unless a more specific notice applies.

When sharing or adapting this material, credit **Jeremy Yang**, identify the work as **Engineering Workspace Compiler (Gift)**, link to `https://github.com/sec-platform/sec` and `https://creativecommons.org/licenses/by/4.0/`, and indicate whether changes were made. Attribution must not imply endorsement.

## Machine-readable classification

[`REUSE.toml`](../REUSE.toml) records the repository-wide SPDX classification. A more specific per-file SPDX notice or an applicable third-party notice takes precedence for that material.

Third-party dependencies and incorporated third-party materials remain under their own licenses. Package-manager metadata and lockfiles identify dependencies; those dependencies are not relicensed by this repository.
